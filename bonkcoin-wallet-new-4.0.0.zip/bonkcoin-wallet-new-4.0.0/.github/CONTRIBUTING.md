# Contributing to Bonkcoin Wallet

We welcome contributions to the Bonkcoin Wallet Android app!

Whether it's fixing bugs, improving performance, or adding new features, your help is appreciated. Before contributing, please follow these guidelines:

## How to Contribute

1. Fork the repository.
2. Create a new branch for your changes.
3. Make your changes and commit with clear messages.
4. Push your branch and submit a pull request.

## Development Notes

- This wallet uses [bitcoinj](https://github.com/bitcoinj/bitcoinj) adapted for Bonkcoin.
- It is an SPV (Simplified Payment Verification) wallet running directly on Android.
- Please test on both real devices and emulators.

## Code Style

Follow Android best practices and Java conventions.

---

Thanks for supporting Bonkcoin!

