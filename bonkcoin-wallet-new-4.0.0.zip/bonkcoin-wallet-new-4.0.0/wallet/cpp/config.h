#define COIN_NAME "Bonkcoin"
#define COIN_TICKER "BONC"
#define NET_MAGIC 0xf9beb4d9
#define DEFAULT_PORT 14327
#define RPC_PORT 15612
#define ADDRESS_PREFIX 0x1e  // Префикс адреса для Bonkcoin

#define HAVE_DECL_BE64ENC 0
#define HAVE_MMAP 1

#ifndef __ANDROID__
#define HAVE_POSIX_MEMALIGN 1
#endif

#ifdef __ANDROID__
#include <sys/limits.h>
#endif
