package org.bonkcoin.wallet;

import org.junit.Test;
import static org.junit.Assert.*;

public class TransactionUtilsTest {

    @Test
    public void testCreateTransaction() throws Exception {
        // Параметры для подключения
        String rpcUser = "rpcuser";  // замените на ваш rpcuser
        String rpcPassword = "rpcpassword";  // замените на ваш rpcpassword
        String rpcUrl = "http://127.0.0.1:15612";  // URL RPC-сервера
        String address = "test_address";  // замените на реальный адрес
        double amount = 0.01;  // сумма транзакции

        // Проверка отправки транзакции
        String txid = TransactionUtils.sendTransaction(rpcUser, rpcPassword, rpcUrl, address, amount);
        assertNotNull(txid);  // Проверка, что ID транзакции не пустой
    }
}
