package org.bonkcoin.wallet;

import org.junit.Test;
import static org.junit.Assert.*;

public class NetworkUtilsTest {

    @Test
    public void testNetworkReachable() {
        // Проверка доступности сети Bonkcoin
        assertTrue(NetworkUtils.isNetworkReachable());
    }
}
