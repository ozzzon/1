package org.bonkcoin.wallet.network;

public class NetworkParameters {
    public static final byte[] PCH_MESSAGE_START = {(byte)0xf9, (byte)0xbe, (byte)0xb4, (byte)0xd9};
    public static final int DEFAULT_PORT = 14327;
    public static final int RPC_PORT = 15612;
    public static final byte ADDRESS_HEADER = 0x1e; // 'B'
    public static final String GENESIS_HASH = "00000abcde..."; // Замените на актуальный хеш
    // Добавьте другие необходимые параметры
}
