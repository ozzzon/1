package org.bonkcoin.wallet;

public class Constants {
    public static final String COIN_NAME = "Bonkcoin";
    public static final String COIN_TICKER = "BONC";
    public static final int ADDRESS_PREFIX = 0x1e; // 'B'
    public static final int DEFAULT_PORT = 14327;
    public static final int RPC_PORT = 15612;
    // Добавьте другие необходимые константы
}
