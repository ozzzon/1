package org.bonkcoin.wallet;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import okhttp3.*;
import java.io.IOException;

public class TransactionUtils {

    // Пример функции для получения нового адреса
    public static String getNewAddress(String rpcUser, String rpcPassword, String rpcUrl) throws IOException {
        String json = "{\"jsonrpc\": \"1.0\", \"id\": \"getnewaddress\", \"method\": \"getnewaddress\", \"params\": []}";
        return sendRpcRequest(rpcUser, rpcPassword, rpcUrl, json);
    }

    // Пример функции для отправки транзакции
    public static String sendTransaction(String rpcUser, String rpcPassword, String rpcUrl, String address, double amount) throws IOException {
        String json = "{\"jsonrpc\": \"1.0\", \"id\": \"sendtoaddress\", \"method\": \"sendtoaddress\", \"params\": [\"" + address + "\", " + amount + "]}";
        return sendRpcRequest(rpcUser, rpcPassword, rpcUrl, json);
    }

    // Общая функция для отправки RPC-запросов
    private static String sendRpcRequest(String rpcUser, String rpcPassword, String rpcUrl, String json) throws IOException {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(MediaType.parse("application/json"), json);
        Request request = new Request.Builder()
                .url(rpcUrl)
                .post(body)
                .addHeader("Authorization", Credentials.basic(rpcUser, rpcPassword))
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("Unexpected code " + response);
        }

        // Парсим ответ
        Gson gson = new Gson();
        JsonObject jsonResponse = gson.fromJson(response.body().string(), JsonObject.class);
        String result = jsonResponse.get("result").getAsString();
        return result;
    }
}
