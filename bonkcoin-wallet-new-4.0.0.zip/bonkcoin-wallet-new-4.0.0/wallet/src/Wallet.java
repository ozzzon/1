package org.bonkcoin.wallet;

import org.bonkcoin.wallet.network.NetworkParameters;

public class Wallet {
    private String address;
    private String privateKey;

    // Конструктор
    public Wallet(String address, String privateKey) {
        this.address = address;
        this.privateKey = privateKey;
    }

    // Получить адрес
    public String getAddress() {
        return address;
    }

    // Получить приватный ключ
    public String getPrivateKey() {
        return privateKey;
    }

    // Функция для синхронизации с сетью
    public void syncWithNetwork() {
        // Здесь будет код для синхронизации кошелька с сетью Bonkcoin
        System.out.println("Synchronizing with network: " + NetworkParameters.GENESIS_HASH);
    }
}
