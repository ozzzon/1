package de.schildbach.wallet.ui.send;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.bonkcoin.core.Address;
import org.bonkcoin.core.Coin;
import org.bonkcoin.core.ECKey;
import org.bonkcoin.core.SendRequest;
import org.bonkcoin.core.Transaction;
import org.bonkcoin.core.Wallet;
import org.bonkcoin.params.BonkcoinMainNetParams;

import de.schildbach.wallet.R;
import de.schildbach.wallet.WalletApplication;

/**
 * Экран отправки монет Bonkcoin.
 */
public class SendCoinsActivity extends AppCompatActivity {

    private EditText addressInput;
    private EditText amountInput;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_coins_activity);

        addressInput = findViewById(R.id.address_input);
        amountInput = findViewById(R.id.amount_input);
        sendButton = findViewById(R.id.send_button);

        sendButton.setOnClickListener(view -> sendCoins());
    }

    private void sendCoins() {
        try {
            String addressStr = addressInput.getText().toString();
            String amountStr = amountInput.getText().toString();

            Address address = Address.fromString(BonkcoinMainNetParams.get(), addressStr);
            Coin amount = Coin.parseCoin(amountStr);

            Wallet wallet = WalletApplication.getWalletKit().wallet();
            SendRequest request = SendRequest.to(address, amount);
            Transaction tx = wallet.sendCoinsOffline(request);

            if (tx != null) {
                Toast.makeText(this, "Транзакция отправлена", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Ошибка при создании транзакции", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
