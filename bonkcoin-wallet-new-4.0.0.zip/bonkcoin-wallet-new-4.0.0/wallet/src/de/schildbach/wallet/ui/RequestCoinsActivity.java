package de.schildbach.wallet.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.bonkcoin.core.Address;
import org.bonkcoin.wallet.Wallet;

import de.schildbach.wallet.R;
import de.schildbach.wallet.WalletApplication;

/**
 * Экран запроса монет Bonkcoin (показ адреса получения).
 */
public class RequestCoinsActivity extends AppCompatActivity {

    private TextView receiveAddressText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.request_coins_activity);

        receiveAddressText = findViewById(R.id.receive_address);

        Wallet wallet = WalletApplication.getWalletKit().wallet();
        Address address = wallet.currentReceiveAddress();
        receiveAddressText.setText(address.toString());
    }
}
