package de.schildbach.wallet.ui.send;

import org.bonkcoin.wallet.Wallet;

public interface SendCoinsFragmentListener {
    void onSendCoinsSuccess(String transactionHash);
    void onSendCoinsCanceled();
    Wallet getWallet();
}
