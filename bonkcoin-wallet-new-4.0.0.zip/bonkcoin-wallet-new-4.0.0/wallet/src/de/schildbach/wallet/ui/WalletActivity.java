package de.schildbach.wallet.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.bonkcoin.core.Wallet;
import org.bonkcoin.kits.WalletAppKit;

import de.schildbach.wallet.R;
import de.schildbach.wallet.WalletApplication;

/**
 * Главный экран приложения Bonkcoin Wallet.
 */
public class WalletActivity extends AppCompatActivity {

    private WalletAppKit kit;
    private TextView balanceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallet_activity);

        balanceView = findViewById(R.id.balance_text);
        kit = WalletApplication.getWalletKit();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Wallet wallet = kit.wallet();
        String balance = wallet.getBalance().toFriendlyString();
        balanceView.setText(balance);
    }
}
