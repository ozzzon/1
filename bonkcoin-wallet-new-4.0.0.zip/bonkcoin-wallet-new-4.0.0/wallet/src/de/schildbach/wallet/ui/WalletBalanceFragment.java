/*
 * Copyright 2014 Andreas Schildbach
 *
 * This file is part of the Bonkcoin Wallet for Android.
 *
 * Licensed under the GNU General Public License, Version 3 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.gnu.org/licenses/gpl-3.0.txt
 */

package de.schildbach.wallet.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.bonkcoin.core.Wallet;

import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.util.WalletUtils;
import de.schildbach.wallet.R;

/**
 * @author Andreas Schildbach
 */
public final class WalletBalanceFragment extends Fragment {
    private WalletApplication application;
    private Wallet wallet;

    private TextView balanceView;

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        return inflater.inflate(R.layout.wallet_balance_fragment, container, false);
    }

    @Override
    public void onViewCreated(final View view, final Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        balanceView = view.findViewById(R.id.wallet_balance);

        application = (WalletApplication) getActivity().getApplication();
        wallet = application.getWallet();

        updateView();
    }

    private void updateView() {
        final String balanceText = WalletUtils.formatValue(wallet.getBalance()) + " BONC";
        balanceView.setText(balanceText);
    }
}
