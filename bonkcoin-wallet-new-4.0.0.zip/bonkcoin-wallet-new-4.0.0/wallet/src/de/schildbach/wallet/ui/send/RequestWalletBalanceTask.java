package de.schildbach.wallet.ui.send;

import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;

import org.bitcoinj.core.*;
import org.bitcoinj.script.Script;
import org.bouncycastle.util.encoders.Hex;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;

public final class RequestWalletBalanceTask {
    private final Handler backgroundHandler;
    private final Handler callbackHandler;
    private final ResultCallback resultCallback;

    private static final Logger log = LoggerFactory.getLogger(RequestWalletBalanceTask.class);

    public interface ResultCallback {
        void onResult(Set<UTXO> utxos);
        void onFail(int messageResId, Object... messageArgs);
    }

    public RequestWalletBalanceTask(final Handler backgroundHandler, final ResultCallback resultCallback) {
        this.backgroundHandler = backgroundHandler;
        this.callbackHandler = new Handler(Looper.myLooper());
        this.resultCallback = resultCallback;
    }

    public void requestWalletBalance(final AssetManager assets, final ECKey key) {
        backgroundHandler.post(() -> {
            org.bitcoinj.core.Context.propagate(Constants.CONTEXT);

            final Address legacyAddress = LegacyAddress.fromKey(Constants.NETWORK_PARAMETERS, key);
            final String addressesStr = legacyAddress.toString();

            List<String> urls = new ArrayList<>(1);
            urls.add(Constants.BLOCKCYPHER_API_URL); // Замените на API Bonkcoin при необходимости
            Collections.shuffle(urls, new Random(System.nanoTime()));

            final StringBuilder url = new StringBuilder(urls.get(0));
            url.append(addressesStr);

            log.debug("trying to request wallet balance from {}", url);

            final Request.Builder request = new Request.Builder();
            request.url(HttpUrl.parse(url.toString()).newBuilder()
                    .encodedQuery("unspentOnly=true&includeScript=true").build());

            final Call call = Constants.HTTP_CLIENT.newCall(request.build());

            try {
                final Response response = call.execute();
                if (response.isSuccessful()) {
                    String content = response.body().string();
                    final JSONObject json = new JSONObject(content);
                    final JSONArray jsonOutputs = json.optJSONArray("txrefs");

                    final Set<UTXO> utxoSet = new HashSet<>();
                    if (jsonOutputs == null) {
                        onResult(utxoSet);
                        return;
                    }

                    for (int i = 0; i < jsonOutputs.length(); i++) {
                        final JSONObject jsonOutput = jsonOutputs.getJSONObject(i);

                        final Sha256Hash utxoHash = Sha256Hash.wrap(jsonOutput.getString("tx_hash"));
                        final int utxoIndex = jsonOutput.getInt("tx_output_n");
                        final byte[] utxoScriptBytes = Hex.decode(jsonOutput.getString("script"));
                        final Coin uxtutx = Coin.valueOf(Long.parseLong(jsonOutput.getString("value")));

                        UTXO utxo = new UTXO(utxoHash, utxoIndex, uxtutx, -1, false, new Script(utxoScriptBytes));
                        utxoSet.add(utxo);
                    }

                    log.info("fetched unspent outputs from {}", url);
                    onResult(utxoSet);
                } else {
                    final String responseMessage = response.message();
                    log.info("got http error '{}: {}' from {}", response.code(), responseMessage, url);
                    onFail(R.string.error_http, response.code(), responseMessage);
                }
            } catch (final JSONException x) {
                log.info("problem parsing json from " + url, x);
                onFail(R.string.error_parse, x.getMessage());
            } catch (final IOException x) {
                log.info("problem querying unspent outputs from " + url, x);
                onFail(R.string.error_io, x.getMessage());
            }
        });
    }

    protected void onResult(final Set<UTXO> utxos) {
        callbackHandler.post(() -> resultCallback.onResult(utxos));
    }

    protected void onFail(final int messageResId, final Object... messageArgs) {
        callbackHandler.post(() -> resultCallback.onFail(messageResId, messageArgs));
    }
}
