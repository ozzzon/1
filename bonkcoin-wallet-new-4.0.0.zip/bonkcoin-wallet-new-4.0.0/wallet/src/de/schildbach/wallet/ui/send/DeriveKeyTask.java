package de.schildbach.wallet.ui.send;

import android.os.Handler;
import android.os.Looper;
import org.bonkcoin.wallet.Constants;
import org.bitcoinj.crypto.KeyCrypter;
import org.bitcoinj.crypto.KeyCrypterException;
import org.bitcoinj.crypto.KeyCrypterScrypt;
import org.bitcoinj.wallet.Wallet;

/**
 * Асинхронная задача для генерации ключа шифрования через Scrypt.
 */
public class DeriveKeyTask {
    public interface Callback {
        void onDerived(KeyCrypter keyCrypter);
        void onException(Exception x);
    }

    public DeriveKeyTask(final Callback callback) {
        new Thread(() -> {
            try {
                final KeyCrypterScrypt keyCrypter = new KeyCrypterScrypt(Constants.SCRYPT_PARAMETERS);
                new Handler(Looper.getMainLooper()).post(() -> callback.onDerived(keyCrypter));
            } catch (final KeyCrypterException x) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onException(x));
            }
        }).start();
    }
}
