package de.schildbach.wallet.ui.send;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import de.schildbach.wallet.R;

public class SendCoinsBroadcastFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_send_coins_broadcast, container, false);
        TextView broadcastStatus = view.findViewById(R.id.broadcast_status);
        broadcastStatus.setText(R.string.broadcasting_transaction);
        return view;
    }
}
