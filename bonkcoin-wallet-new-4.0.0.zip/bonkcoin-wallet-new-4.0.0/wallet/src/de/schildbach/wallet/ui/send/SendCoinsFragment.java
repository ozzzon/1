/*
 * Copyright 2014 Andreas Schildbach
 *
 * This file is part of the Bonkcoin Wallet for Android.
 *
 * Licensed under the GNU General Public License, Version 3 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.gnu.org/licenses/gpl-3.0.txt
 */

package de.schildbach.wallet.ui.send;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.bonkcoin.core.Address;
import org.bonkcoin.core.Coin;
import org.bonkcoin.core.NetworkParameters;
import org.bonkcoin.wallet.Wallet;

import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.util.WalletUtils;
import de.schildbach.wallet.R;

/**
 * Fragment responsible for input of recipient address and BONC amount.
 */
public final class SendCoinsFragment extends Fragment {
    private WalletApplication application;
    private Wallet wallet;

    private EditText recipientAddressView;
    private EditText amountView;
    private TextView balanceView;

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_send_coins, container, false);
    }

    @Override
    public void onViewCreated(final View view, final Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        application = (WalletApplication) getActivity().getApplication();
        wallet = application.getWallet();

        recipientAddressView = view.findViewById(R.id.send_coins_address);
        amountView = view.findViewById(R.id.send_coins_amount);
        balanceView = view.findViewById(R.id.send_coins_balance);

        updateBalance();
    }

    private void updateBalance() {
        final Coin balance = wallet.getBalance();
        final String balanceText = WalletUtils.formatValue(balance) + " BONC";
        balanceView.setText(balanceText);
    }
}
