package de.schildbach.wallet.ui.send;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;

import org.bonkcoin.core.Address;
import org.bonkcoin.core.Coin;
import org.bonkcoin.params.MainNetParams;

import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import de.schildbach.wallet.util.Qr;

public final class SendCoinsQrActivity extends AppCompatActivity {
    public static final String INTENT_EXTRA_ADDRESS = "address";
    public static final String INTENT_EXTRA_AMOUNT = "amount";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_coins_qr);

        final ImageView qrView = findViewById(R.id.qr_view);
        final TextView addressView = findViewById(R.id.address);

        final String addressStr = getIntent().getStringExtra(INTENT_EXTRA_ADDRESS);
        final Address address = Address.fromString(Constants.NETWORK_PARAMETERS, addressStr);
        final Coin amount = Coin.valueOf(getIntent().getLongExtra(INTENT_EXTRA_AMOUNT, 0L));

        addressView.setText(address.toString());

        final String uri = "bonk:" + address.toString() + "?amount=" + amount.toPlainString();

        try {
            final Bitmap qrCode = Qr.bitmap(uri, BarcodeFormat.QR_CODE);
            qrView.setImageBitmap(qrCode);
        } catch (WriterException e) {
            e.printStackTrace();
            setResult(Activity.RESULT_CANCELED);
            finish();
        }
    }
}
