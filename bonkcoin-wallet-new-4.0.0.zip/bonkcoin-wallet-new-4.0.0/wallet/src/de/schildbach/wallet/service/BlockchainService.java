package de.schildbach.wallet.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;

import org.bonkcoin.core.NetworkParameters;
import org.bonkcoin.kits.WalletAppKit;
import org.bonkcoin.params.BonkcoinMainNetParams;
import org.bonkcoin.params.BonkcoinTestNetParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.schildbach.wallet.Constants;
import de.schildbach.wallet.WalletApplication;

/**
 * Сервис Android для запуска SPV-синхронизации Bonkcoin.
 */
public class BlockchainService extends Service {
    private WalletAppKit kit;
    private PowerManager.WakeLock wakeLock;
    private static final Logger log = LoggerFactory.getLogger(BlockchainService.class);

    @Override
    public void onCreate() {
        super.onCreate();
        log.info("Создание BlockchainService");

        final PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bonkcoin:sync-lock");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();

        NetworkParameters params = Constants.NETWORK_PARAMETERS;
        kit = WalletApplication.getWalletKit();
        kit.startAsync();
        kit.awaitRunning();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        log.info("Запуск BlockchainService");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        log.info("Остановка BlockchainService");

        if (kit != null) {
            kit.stopAsync();
            kit.awaitTerminated();
        }

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
