package de.schildbach.wallet;

import android.os.Build;
import android.text.format.DateUtils;
import com.google.common.io.BaseEncoding;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import org.bitcoinj.core.Coin;
import org.bitcoinj.core.Context;
import org.bitcoinj.core.NetworkParameters;
import org.bitcoinj.script.Script;
import org.bitcoinj.utils.MonetaryFormat;
import org.bonkcoin.params.BonkcoinMainNetParams;
import org.bonkcoin.params.BonkcoinTestNetParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public final class Constants {

    public static final NetworkParameters NETWORK_PARAMETERS =
            !BuildConfig.FLAVOR.equals("prod") ? BonkcoinTestNetParams.get() : BonkcoinMainNetParams.get();

    public static final Context CONTEXT = new Context(NETWORK_PARAMETERS);

    public static final Script.ScriptType DEFAULT_OUTPUT_SCRIPT_TYPE = Script.ScriptType.P2PKH;
    public static final Script.ScriptType UPGRADE_OUTPUT_SCRIPT_TYPE = Script.ScriptType.P2PKH;

    public static final boolean ENABLE_BLOCKCHAIN_SYNC = true;
    public static final boolean ENABLE_EXCHANGE_RATES = true;
    public static final boolean ENABLE_SWEEP_WALLET = true;
    public static final boolean ENABLE_BROWSE = true;

    public final static class Files {
        private static final String FILENAME_NETWORK_SUFFIX = NETWORK_PARAMETERS.getId()
                .equals("org.bonkcoin.production") ? "" : "-testnet";

        public static final String WALLET_FILENAME_PROTOBUF = "wallet-protobuf" + FILENAME_NETWORK_SUFFIX;
        public static final long WALLET_AUTOSAVE_DELAY_MS = 3 * DateUtils.SECOND_IN_MILLIS;
        public static final String WALLET_KEY_BACKUP_BASE58 = "key-backup-base58" + FILENAME_NETWORK_SUFFIX;
        public static final String WALLET_KEY_BACKUP_PROTOBUF = "key-backup-protobuf" + FILENAME_NETWORK_SUFFIX;
        public static final String EXTERNAL_WALLET_BACKUP = "bonkcoin-wallet-backup" + FILENAME_NETWORK_SUFFIX;
        public static final String BLOCKCHAIN_FILENAME = "blockchain" + FILENAME_NETWORK_SUFFIX;
        public static final int BLOCKCHAIN_STORE_CAPACITY = 10000;
        public static final String CHECKPOINTS_ASSET = "checkpoints.txt";
        public static final String FEES_ASSET = "fees.txt";
        public static final String FEES_FILENAME = "fees" + FILENAME_NETWORK_SUFFIX + ".txt";
        public static final String ELECTRUM_SERVERS_ASSET = "electrum-servers.txt";
    }

    public static final HttpUrl VERSION_URL = HttpUrl.parse("https://maxkeller.io/version"
            + (NETWORK_PARAMETERS.getId().equals(NetworkParameters.ID_MAINNET) ? "" : "-test"));
    public static final HttpUrl DYNAMIC_FEES_URL = HttpUrl.parse("https://wallet.schildbach.de/fees");

    public static final String MIMETYPE_TRANSACTION = "application/x-bonktx";
    public static final String MIMETYPE_WALLET_BACKUP = "application/x-bonkcoin-wallet-backup";

    public static final int MAX_NUM_CONFIRMATIONS = 7;
    public static final String USER_AGENT = "Bonkcoin Wallet";
    public static final String DEFAULT_EXCHANGE_CURRENCY = "USD";
    public static final String DONATION_ADDRESS = null;
    public static final String REPORT_EMAIL = "bonkcoinandroid@gmail.com";
    public static final String REPORT_SUBJECT_ISSUE = "Reported issue";
    public static final String REPORT_SUBJECT_CRASH = "Crash report";

    public static final char CHAR_HAIR_SPACE = '\u200a';
    public static final char CHAR_THIN_SPACE = '\u2009';
    public static final char CHAR_BITCOIN = '\u00d0';
    public static final char CHAR_ALMOST_EQUAL_TO = '\u2248';
    public static final char CHAR_CHECKMARK = '\u2713';
    public static final char CHAR_CROSSMARK = '\u2715';
    public static final char CURRENCY_PLUS_SIGN = '\uff0b';
    public static final char CURRENCY_MINUS_SIGN = '\uff0d';
    public static final String PREFIX_ALMOST_EQUAL_TO = Character.toString(CHAR_ALMOST_EQUAL_TO) + CHAR_THIN_SPACE;

    public static final int ADDRESS_FORMAT_GROUP_SIZE = 4;
    public static final int ADDRESS_FORMAT_LINE_SIZE = 12;
    public static final MonetaryFormat LOCAL_FORMAT = new MonetaryFormat().noCode().minDecimals(4).optionalDecimals();

    public static final BaseEncoding HEX = BaseEncoding.base16().lowerCase();

    public static final String BLOCKCYPHER_API_URL = "https://api.blockcypher.com/v1/doge/main/addrs/";
    public static final String SOURCE_URL = "https://github.com/Bonkcoin/Bonkcoin-core";
    public static final String BINARY_URL = "https://github.com/Bonkcoin/Bonkcoin-core/releases/latest";

    public static final int PEER_DISCOVERY_TIMEOUT_MS = 5 * (int) DateUtils.SECOND_IN_MILLIS;
    public static final int PEER_TIMEOUT_MS = 15 * (int) DateUtils.SECOND_IN_MILLIS;

    public static final long LAST_USAGE_THRESHOLD_JUST_MS = DateUtils.HOUR_IN_MILLIS;
    public static final long LAST_USAGE_THRESHOLD_TODAY_MS = DateUtils.DAY_IN_MILLIS;
    public static final long LAST_USAGE_THRESHOLD_RECENTLY_MS = DateUtils.WEEK_IN_MILLIS;
    public static final long LAST_USAGE_THRESHOLD_INACTIVE_MS = 4 * DateUtils.WEEK_IN_MILLIS;

    public static final long DELAYED_TRANSACTION_THRESHOLD_MS = 2 * DateUtils.HOUR_IN_MILLIS;
    public static final long AUTOCLOSE_DELAY_MS = 1000;

    public static final Coin TOO_MUCH_BALANCE_THRESHOLD = Coin.COIN.multiply(10000);
    public static final Coin SOME_BALANCE_THRESHOLD = Coin.COIN.multiply(100);

    public static final int SDK_DEPRECATED_BELOW = Build.VERSION_CODES.M;
    public static final String SECURITY_PATCH_INSECURE_BELOW = "2018-01-01";

    public static final int NOTIFICATION_ID_CONNECTIVITY = 1;
    public static final int NOTIFICATION_ID_COINS_RECEIVED = 2;
    public static final int NOTIFICATION_ID_BLUETOOTH = 3;
    public static final int NOTIFICATION_ID_INACTIVITY = 4;
    public static final String NOTIFICATION_GROUP_KEY_RECEIVED = "group-received";
    public static final String NOTIFICATION_CHANNEL_ID_RECEIVED = "received";
    public static final String NOTIFICATION_CHANNEL_ID_ONGOING = "ongoing";
    public static final String NOTIFICATION_CHANNEL_ID_IMPORTANT = "important";

    public static final int SCRYPT_ITERATIONS_TARGET = 65536;
    public static final int SCRYPT_ITERATIONS_TARGET_LOWRAM = 32768;

    public static final int ELECTRUM_SERVER_DEFAULT_PORT_TCP = NETWORK_PARAMETERS.getId()
            .equals(NetworkParameters.ID_MAINNET) ? 50001 : 51001;
    public static final int ELECTRUM_SERVER_DEFAULT_PORT_TLS = NETWORK_PARAMETERS.getId()
            .equals(NetworkParameters.ID_MAINNET) ? 50002 : 51002;

    public static final OkHttpClient HTTP_CLIENT;
    static {
        final HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(message -> log.debug(message));
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);

        final OkHttpClient.Builder httpClientBuilder = new OkHttpClient.Builder();
        httpClientBuilder.followRedirects(false);
        httpClientBuilder.followSslRedirects(true);
        httpClientBuilder.connectTimeout(15, TimeUnit.SECONDS);
        httpClientBuilder.writeTimeout(15, TimeUnit.SECONDS);
        httpClientBuilder.readTimeout(15, TimeUnit.SECONDS);
        httpClientBuilder.addInterceptor(loggingInterceptor);
        HTTP_CLIENT = httpClientBuilder.build();
    }

    private static final Logger log = LoggerFactory.getLogger(Constants.class);
}
