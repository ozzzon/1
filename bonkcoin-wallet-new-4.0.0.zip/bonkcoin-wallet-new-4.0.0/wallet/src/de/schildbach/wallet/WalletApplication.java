package de.schildbach.wallet;

import android.app.Application;
import android.content.Context;

import org.bonkcoin.kits.WalletAppKit;
import org.bonkcoin.params.BonkcoinMainNetParams;
import org.bonkcoin.params.BonkcoinTestNetParams;
import org.bonkcoin.core.NetworkParameters;

import java.io.File;

import de.schildbach.wallet.integration.android.Constants;

/**
 * Главный класс приложения Bonkcoin Wallet
 */
public class WalletApplication extends Application {
    private static WalletApplication instance;
    private WalletAppKit kit;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        final File filesDir = getDir("wallet", Context.MODE_PRIVATE);
        NetworkParameters params = Constants.NETWORK_PARAMETERS;

        kit = new WalletAppKit(params, filesDir, "bonkcoin_wallet") {
            @Override
            protected void onSetupCompleted() {
                // Можно добавить дополнительные настройки здесь
            }
        };
    }

    public static WalletApplication getInstance() {
        return instance;
    }

    public static WalletAppKit getWalletKit() {
        return instance.kit;
    }
} 
