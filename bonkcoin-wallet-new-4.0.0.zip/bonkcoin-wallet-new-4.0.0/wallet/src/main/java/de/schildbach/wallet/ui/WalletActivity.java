package de.schildbach.wallet.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import de.schildbach.wallet.Constants;
import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.R;

import org.bitcoinj.core.NetworkParameters;
import org.bitcoinj.wallet.Wallet;

/**
 * Главная активность приложения Bonkcoin Wallet.
 */
public final class WalletActivity extends AppCompatActivity {

    private WalletApplication application;
    private Wallet wallet;
    private NetworkParameters params;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallet_activity);

        application = (WalletApplication) getApplication();
        wallet = application.getWallet();
        params = application.getParams();

        // Инициализация пользовательского интерфейса, обработка событий и т.д.
        // TODO: добавить фрагменты и адаптеры
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.wallet_options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_receive) {
            startActivity(new Intent(this, RequestCoinsActivity.class));
            return true;
        } else if (id == R.id.menu_send) {
            startActivity(new Intent(this, SendCoinsActivity.class));
            return true;
        } else if (id == R.id.menu_settings) {
            startActivity(new Intent(this, PreferencesActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
