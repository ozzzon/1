package de.schildbach.wallet.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import org.bitcoinj.core.Transaction;
import org.bitcoinj.wallet.Wallet;

import java.text.DateFormat;
import java.util.Date;

import de.schildbach.wallet.BonkcoinUtils;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.util.WalletUtils;

public final class TransactionDetailsActivity extends Activity {
    public static final String EXTRA_TRANSACTION_HASH = "transaction_hash";

    private Wallet wallet;
    private Transaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transaction_details_activity);

        final WalletApplication application = (WalletApplication) getApplication();
        wallet = application.getWallet();

        final String txHash = getIntent().getStringExtra(EXTRA_TRANSACTION_HASH);
        if (txHash != null) {
            transaction = wallet.getTransaction(Sha256Hash.wrap(txHash));
        }

        if (transaction == null) {
            finish();
            return;
        }

        bindView();
    }

    private void bindView() {
        final TextView txHashView = findViewById(R.id.transaction_hash);
        final TextView txAmountView = findViewById(R.id.transaction_amount);
        final TextView txFeeView = findViewById(R.id.transaction_fee);
        final TextView txDateView = findViewById(R.id.transaction_date);
        final TextView txConfirmationsView = findViewById(R.id.transaction_confirmations);

        txHashView.setText(transaction.getTxId().toString());

        txAmountView.setText(BonkcoinUtils.formatValue(transaction.getValue(wallet), true));
        txFeeView.setText(transaction.getFee() != null ?
                BonkcoinUtils.formatValue(transaction.getFee(), true) : getString(R.string.transaction_fee_unknown));

        DateFormat dateFormat = DateFormat.getDateTimeInstance();
        Date txTime = transaction.getUpdateTime();
        txDateView.setText(dateFormat.format(txTime));

        int confirmations = wallet.getBlockchainHeight() - transaction.getAppearsInBestChainHeight() + 1;
        txConfirmationsView.setText(getString(R.string.transaction_confirmations, confirmations));
    }
}
