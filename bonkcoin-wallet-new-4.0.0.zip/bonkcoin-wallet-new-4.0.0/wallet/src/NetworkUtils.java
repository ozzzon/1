package org.bonkcoin.wallet.network;

import org.bonkcoin.wallet.Constants;

public class NetworkUtils {

    // Проверка подключения к сети
    public static boolean isNetworkReachable() {
        // Логика проверки доступности сети Bonkcoin
        System.out.println("Checking network: " + Constants.COIN_NAME);
        return true; // Заглушка, нужно добавить реальную логику
    }
}
