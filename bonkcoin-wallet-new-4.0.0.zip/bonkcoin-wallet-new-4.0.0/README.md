# Bonkcoin Wallet for Android

This is **Bonkcoin Wallet**, a standalone SPV (Simplified Payment Verification) wallet for Android.

It is based on the Dogecoin Wallet app and powered by a fork of [bitcoinj](https://github.com/bitcoinj/bitcoinj), modified for Bonkcoin's network parameters.

---

## 🔧 Components

- **wallet/** – Android wallet app.
- **market/** – Store listing resources (e.g., description, screenshots).
- **integration-android/** – Library for integrating Bonkcoin payments.
- **sample-integration-android/** – Example integration app.

---

## 🚀 Building the App

You'll need:

- Java 8 or higher
- Android Studio (with Android SDK)
- Gradle 7.0+

To build:

```bash
git clone https://github.com/YOUR-FORK/bonkcoin-wallet.git
cd bonkcoin-wallet
./gradlew assembleDebug

