package de.schildbach.wallet.integration.android;

import org.bonkcoin.params.BonkcoinMainNetParams;
import org.bonkcoin.core.NetworkParameters;

/**
 * Константы конфигурации для Bonkcoin.
 */
public final class Constants {
    public static final NetworkParameters NETWORK_PARAMETERS = BonkcoinMainNetParams.get();

    private Constants() {
    }
}
