package org.bonkcoin.wallet.integration.android;

import android.app.Activity;
import android.content.Intent;

/**
 * Helper class to integrate Bonkcoin Wallet with Android apps via intents.
 */
public class BonkcoinIntegration {
    public static final String ACTION_SEND = "org.bonkcoin.wallet.SEND";
    public static final String EXTRA_ADDRESS = "address";
    public static final String EXTRA_AMOUNT = "amount";
    public static final String EXTRA_LABEL = "label";

    public static void sendBonkcoin(Activity activity, String address, long amount, String label) {
        Intent intent = new Intent(ACTION_SEND);
        intent.putExtra(EXTRA_ADDRESS, address);
        intent.putExtra(EXTRA_AMOUNT, amount);
        intent.putExtra(EXTRA_LABEL, label);
        activity.startActivity(intent);
    }
}
