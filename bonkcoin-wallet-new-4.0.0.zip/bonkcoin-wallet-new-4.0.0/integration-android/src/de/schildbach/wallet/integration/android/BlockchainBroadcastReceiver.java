package de.schildbach.wallet.integration.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import de.schildbach.wallet.service.BlockchainService;

/**
 * Получатель широковещательных сообщений, запускающий синхронизацию блокчейна Bonkcoin.
 */
public class BlockchainBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("BlockchainReceiver", "Получен Broadcast: запуск BlockchainService");
        context.startService(new Intent(context, BlockchainService.class));
    }
}
